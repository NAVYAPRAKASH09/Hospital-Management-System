-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2020 at 04:31 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospitalms`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` varchar(10) NOT NULL COMMENT 'The unique key that identifies the appointments.',
  `patient_id` varchar(8) NOT NULL COMMENT 'The patient ID refers to the patient that made the appointment,',
  `doc_id` varchar(4) NOT NULL COMMENT 'Doc ID refers to the doctor that the patient is scheduled to see.',
  `f_id` varchar(5) NOT NULL COMMENT 'The front desk employee that initiated the appointment.',
  `date` date NOT NULL COMMENT 'Date of appointment.',
  `time` time NOT NULL COMMENT 'Time of the scheduled appointment',
  `is_admit` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Whether patient has to be admitted.',
  `is_operate` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Whether an operation is required.',
  `diagnosis_id` varchar(10) NOT NULL COMMENT 'The diagnosis of the doctor is filled out here.',
  `consulting_price` varchar(5) NOT NULL COMMENT 'The price for consultation.',
  `paid` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Whether the bill has been paid',
  `cancelled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Whether the bill has been cancelled'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains all of the appointments coming through the hospital. Core table';

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `patient_id`, `doc_id`, `f_id`, `date`, `time`, `is_admit`, `is_operate`, `diagnosis_id`, `consulting_price`, `paid`, `cancelled`) VALUES
('A1', 'P1', 'D1', 'F1', '2020-03-05', '09:00:00', 0, 0, 'Di1', '1200', 1, 0),
('A2', 'P1', 'D1', 'F1', '2020-03-05', '09:00:00', 0, 0, 'Di2', '1200', 1, 0),
('A3', 'P1', 'D1', 'F1', '2020-03-05', '09:00:00', 0, 0, 'Di3', '1200', 0, 1),
('A4', 'P1', 'D2', 'F1', '2020-03-05', '09:00:00', 0, 0, 'Di4', '1235', 1, 0),
('A5', 'P1', 'D2', 'F1', '2020-03-05', '09:00:00', 0, 0, 'Di5', '1235', 0, 1),
('A6', 'P1', 'D2', 'F1', '2020-03-05', '09:00:00', 0, 0, 'Di6', '1235', 0, 1),
('A7', 'P1', 'D2', 'F1', '2020-03-06', '09:00:00', 0, 0, 'Di7', '1235', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_operation`
--

CREATE TABLE `appointment_operation` (
  `appointment_id` varchar(10) NOT NULL COMMENT 'Unique appointment identifier.',
  `operation_id` varchar(10) NOT NULL COMMENT 'The operation ID identifies the operation uniquely.',
  `op_id` varchar(10) NOT NULL COMMENT 'The operation identifier which is unique',
  `type` varchar(100) NOT NULL COMMENT 'The type of operation being performed.',
  `result` varchar(50) NOT NULL DEFAULT 'Failed.' COMMENT 'The result of the operation.',
  `number_of_hours` int(2) NOT NULL COMMENT 'The number of hours the operation procedure took place.',
  `charge` int(9) NOT NULL COMMENT 'The price of the operation.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains information about the procedures in the hospital.';

--
-- Dumping data for table `appointment_operation`
--

INSERT INTO `appointment_operation` (`appointment_id`, `operation_id`, `op_id`, `type`, `result`, `number_of_hours`, `charge`) VALUES
('A4', 'O1', '1', 'Hormonal Imbalance', '0', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_room`
--

CREATE TABLE `appointment_room` (
  `appointment_id` varchar(10) NOT NULL COMMENT 'Unique appointment ID that identifies the appointment and hence all the other info.',
  `room_id` varchar(4) NOT NULL COMMENT 'The room that is designated to the patient.',
  `food` varchar(15) NOT NULL COMMENT 'Food choice of the inpatient.',
  `date_of_admission` date NOT NULL COMMENT 'Date of admission of the patient.',
  `date_of_discharge` date NOT NULL COMMENT 'Date of discharge of the patient.',
  `number_of_days` int(4) NOT NULL DEFAULT 0 COMMENT 'Number of days that the patient is admitted.',
  `charge` int(10) NOT NULL COMMENT 'The price of the stay.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the appointment info of inpatients in rooms.';

--
-- Dumping data for table `appointment_room`
--

INSERT INTO `appointment_room` (`appointment_id`, `room_id`, `food`, `date_of_admission`, `date_of_discharge`, `number_of_days`, `charge`) VALUES
('A3', 'R1', 'Regular', '2020-03-02', '2020-03-03', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `consulting_time`
--

CREATE TABLE `consulting_time` (
  `doc_id` varchar(4) NOT NULL COMMENT 'The unique identifier for doctors.',
  `days_of_week` int(7) NOT NULL COMMENT 'The days of week the dcotor comes in. From 1-7',
  `time` time NOT NULL COMMENT 'time of arrival of the doctor.',
  `no_of_hours` varchar(2) NOT NULL COMMENT 'The number of hours the doctor accepts consultations.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains information about the doctors consultation timings';

--
-- Dumping data for table `consulting_time`
--

INSERT INTO `consulting_time` (`doc_id`, `days_of_week`, `time`, `no_of_hours`) VALUES
('D1', 123, '09:00:00', '3'),
('D2', 145, '09:00:00', '4');

-- --------------------------------------------------------

--
-- Table structure for table `contact_info`
--

CREATE TABLE `contact_info` (
  `id` varchar(10) NOT NULL COMMENT 'The unique ID identifying the user.',
  `ph_no1` varchar(10) NOT NULL COMMENT 'Phone number of work.',
  `ph_no2` varchar(10) DEFAULT NULL COMMENT 'Phone number home.',
  `email` varchar(25) NOT NULL COMMENT 'Email of the user',
  `house_no` int(4) NOT NULL COMMENT 'House number of the user.',
  `street_name` varchar(25) NOT NULL COMMENT 'Street of residence of the user.',
  `city` varchar(30) NOT NULL COMMENT 'City of residence'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains all of the contact info of the employees and the patients.';

--
-- Dumping data for table `contact_info`
--

INSERT INTO `contact_info` (`id`, `ph_no1`, `ph_no2`, `email`, `house_no`, `street_name`, `city`) VALUES
('D1', '9898989898', 'NULL', 'Akshay@gmail.com', 45, 'Kammanahalli', 'Bangalore'),
('D2', '9797979797', 'NULL', 'svetha1234@gmail.com', 1302, 'L&T', 'Bangalore'),
('F1', '9898989898', 'NULL', 'popeye@gmail.com', 67, 'CV RamanNagar', 'Bangalore'),
('N1', '98989898', 'NULL', 'navya@gmail.com', 45, 'Basavanagudi', 'Bangalore'),
('P1', '9898989898', 'NULL', 'veena@gmail.com', 906, 'kaggadasapura', 'bangalore');

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis`
--

CREATE TABLE `diagnosis` (
  `appointment_id` varchar(9) NOT NULL COMMENT 'Unique appointment identifier.',
  `diagnosis_id` varchar(9) NOT NULL COMMENT 'The ID of the diagnosis records.',
  `patient_condition` varchar(100) NOT NULL COMMENT 'Condition of the patient/the disease.',
  `history` varchar(200) NOT NULL COMMENT 'Brief history of the patients condition.',
  `care` varchar(100) NOT NULL COMMENT 'brief notes about the care to be taken by patient.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the diagnosis of the patient with comments.';

--
-- Dumping data for table `diagnosis`
--

INSERT INTO `diagnosis` (`appointment_id`, `diagnosis_id`, `patient_condition`, `history`, `care`) VALUES
('A3', 'Di3', 'KneePain', 'Hormonal Imbalance	', 'Proper food habits'),
('A4', 'Di4', 'Hormonal Imbalance', 'Obesity	', 'Workout'),
('A5', 'Di5', 'Hormonal Imbalance', 'Obesity		', 'Proper Diet and Workout');

-- --------------------------------------------------------

--
-- Table structure for table `doc_info`
--

CREATE TABLE `doc_info` (
  `doc_id` varchar(5) NOT NULL COMMENT 'Unique id assigned to the dcotors to identify them in the system. Starts with ''d''.',
  `name` varchar(30) NOT NULL COMMENT 'Name of the doctor.',
  `age` varchar(2) NOT NULL COMMENT 'Age of the doctor',
  `sex` varchar(10) NOT NULL COMMENT 'Gender of the doctor',
  `lic_no` varchar(7) NOT NULL COMMENT 'Unique license number of the doctor awarded by the state medical council',
  `state_medical_council` varchar(30) NOT NULL COMMENT 'The state medical council which awarded the license to practice.',
  `qualification_year` varchar(4) NOT NULL COMMENT 'The year of qualification for practice.',
  `specialization` varchar(30) NOT NULL COMMENT 'major specialization of the doctor.',
  `years_of_experience` varchar(2) NOT NULL COMMENT 'The number of years of practice/Experience.',
  `blood_group` varchar(4) NOT NULL COMMENT 'The blood group of the doctor.',
  `consulting_price` varchar(4) NOT NULL COMMENT 'The consulting price of the appointment.',
  `insurance_id` varchar(10) NOT NULL COMMENT 'The insurance ID of the doctor(Health).',
  `employed` varchar(2) NOT NULL DEFAULT '1' COMMENT 'Whether the doctor is employed or not.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Table contains all of the information regarding the doctor. Basic information along with insurance foreign key is also present.';

--
-- Dumping data for table `doc_info`
--

INSERT INTO `doc_info` (`doc_id`, `name`, `age`, `sex`, `lic_no`, `state_medical_council`, `qualification_year`, `specialization`, `years_of_experience`, `blood_group`, `consulting_price`, `insurance_id`, `employed`) VALUES
('D1', 'Akshay', '28', 'MALE', '1234', 'Andhra Pradesh Medical Council', '1999', 'Opthalmology', '2', 'K+', '1200', '1234ABCD', '1'),
('D2', 'Svetha', '30', 'FEMALE', '567', 'Andhra Pradesh Medical Council', '2012', 'Gyneacology', '4', 'O+', '1235', '123ABC', '1');

-- --------------------------------------------------------

--
-- Table structure for table `emergency_contact`
--

CREATE TABLE `emergency_contact` (
  `id` varchar(10) NOT NULL COMMENT 'Unique ID of the users and patients.',
  `name_of_contact` varchar(30) NOT NULL COMMENT 'Name of the emergency contact.',
  `contact_number` varchar(10) NOT NULL COMMENT 'Contact number of the emergency contact.',
  `relation` varchar(15) NOT NULL COMMENT 'Relation to the user (ID)',
  `email` varchar(30) NOT NULL COMMENT 'Email of the emergency contact',
  `street_name` varchar(30) NOT NULL COMMENT 'street name of the emergency contact',
  `city` varchar(30) NOT NULL COMMENT 'City of residence of the emergency contact'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains all of the emergency contact info of users and patients.';

--
-- Dumping data for table `emergency_contact`
--

INSERT INTO `emergency_contact` (`id`, `name_of_contact`, `contact_number`, `relation`, `email`, `street_name`, `city`) VALUES
('D1', 'Raju', '9898989898', 'father', 'raju@gmail.com', 'Kammanahalli', 'Bangalore'),
('D2', 'Venkatrama', '969696969', 'Father', 'venkatrman@gmail.com', 'Mico Layout', 'Bangalore'),
('F1', 'Kali', '9797979797', 'Dog', 'kali@gmail.com', 'Kaggadasapura', 'Bangalore'),
('N1', 'Shravya', '345678', 'Mother', 'qwerty@gmail.com', 'Basavanagudi', 'Bangalore');

-- --------------------------------------------------------

--
-- Table structure for table `front_desk_info`
--

CREATE TABLE `front_desk_info` (
  `f_id` varchar(4) NOT NULL COMMENT 'The unique ID given to the front desk.',
  `name` varchar(30) NOT NULL COMMENT 'name of the employee',
  `age` varchar(2) NOT NULL COMMENT 'Age of the employee',
  `sex` varchar(8) NOT NULL COMMENT 'Gender of the employee',
  `years_of_experience` varchar(2) NOT NULL COMMENT 'The years of experiencee.',
  `blood_group` varchar(4) NOT NULL COMMENT 'Blood group type of employee',
  `insurance_id` varchar(10) NOT NULL COMMENT 'Unique insurance id of the front desk employee.',
  `employed` varchar(2) NOT NULL COMMENT 'Whether the employee is employed or not'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains basic info of a front desk employee.';

--
-- Dumping data for table `front_desk_info`
--

INSERT INTO `front_desk_info` (`f_id`, `name`, `age`, `sex`, `years_of_experience`, `blood_group`, `insurance_id`, `employed`) VALUES
('F1', 'Popeye', '35', 'MALE', '3', 'B+', '1adc2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `insurance_info`
--

CREATE TABLE `insurance_info` (
  `insurance_id` varchar(10) NOT NULL COMMENT 'The unique insurance ID of the user',
  `company` varchar(20) NOT NULL COMMENT 'Company providing the insurance.',
  `amount` int(10) NOT NULL COMMENT 'The insured amount specified in the insurance.',
  `validity` date NOT NULL COMMENT 'The date till which the insurance is valid.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains insurance information of all the users and patients';

--
-- Dumping data for table `insurance_info`
--

INSERT INTO `insurance_info` (`insurance_id`, `company`, `amount`, `validity`) VALUES
('1234ABCD', 'Bajaj', 120000, '1996-02-20'),
('1234ADC', 'Kotak', 123000, '2034-02-24'),
('123ABC', 'KOTAK', 135000, '2020-08-24'),
('1adc2', 'Kotak', 1250000, '2023-02-28');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(5) NOT NULL COMMENT 'The unique ID''s assigned to doctors,nurses,front desk employees and the patients.',
  `password` varchar(100) NOT NULL COMMENT 'Password.',
  `role` varchar(10) NOT NULL COMMENT 'The role of the user logging in. Based on username.',
  `logged` tinyint(1) NOT NULL COMMENT 'Whether the user is currently logged on or not.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Table contains the usernames and passwords which will be use';

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `role`, `logged`) VALUES
('1', '$2a$12$rDC.1xqi1Y4iPxCdQNecEubAlO13AbLvRgRXrRxHkRJgfi2C02GlO', 'admin', 0),
('D1', '$2a$12$lOnXWJvQ8vxlFNNR/hQ28OvtVFbFVRc6jr2lfLou66JRbwyBpxYjy', 'doctor', 0),
('D2', '$2a$12$JO70Aksc5pLmZfEXpN/f2e48k.eq/Bnro7XpgfmsWA4DT3jhXcsKS', 'doctor', 0),
('F1', '$2a$12$7WrWcbGR4Z09SPVQNt05uO5fR6X4xqRUrLl7Lh0CutZ0Fh5OoiPEm', 'frontdesk', 0),
('N1', '$2a$12$QJHl5V8Q3.inMkMGhZsK2uqSV/rsrA0gM0W5WPPmOWrZiKYEJ56KG', 'nurse', 0);

-- --------------------------------------------------------

--
-- Table structure for table `log_times`
--

CREATE TABLE `log_times` (
  `id` varchar(10) NOT NULL COMMENT 'The id''s of end users',
  `date_login` date NOT NULL COMMENT 'The date of login',
  `login_time` time NOT NULL COMMENT 'The login time of user',
  `logout_time` time DEFAULT NULL COMMENT 'The logout time of user.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Maintains login logout times and dates of all end users';

--
-- Dumping data for table `log_times`
--

INSERT INTO `log_times` (`id`, `date_login`, `login_time`, `logout_time`) VALUES
('D1', '2020-03-02', '21:01:17', '21:03:39'),
('D1', '2020-03-02', '21:03:54', '21:05:52'),
('D1', '2020-03-02', '21:06:03', '21:07:07'),
('D1', '2020-03-02', '21:08:53', '21:08:59'),
('D1', '2020-03-03', '18:42:48', '18:43:21'),
('D1', '2020-03-03', '18:45:49', '18:45:59'),
('D1', '2020-03-03', '18:52:14', '18:52:26'),
('D1', '2020-03-03', '18:55:30', '18:55:34'),
('D1', '2020-03-03', '19:44:22', '19:44:45'),
('D2', '2020-03-02', '21:10:49', '21:12:43'),
('D2', '2020-03-02', '21:13:00', '21:13:29'),
('D2', '2020-03-02', '21:13:35', '21:14:14'),
('D2', '2020-03-03', '18:46:04', '18:46:18'),
('D2', '2020-03-03', '18:52:33', '18:52:47'),
('D2', '2020-03-03', '18:55:38', '18:55:55'),
('F1', '2020-03-03', '18:43:26', '18:43:39'),
('F1', '2020-03-03', '18:45:00', '18:45:41'),
('F1', '2020-03-03', '18:54:33', '18:55:25'),
('F1', '2020-03-03', '19:11:06', '19:12:25'),
('F1', '2020-03-03', '19:15:18', '19:15:47'),
('F1', '2020-03-03', '19:18:09', '19:20:07'),
('F1', '2020-03-03', '19:20:22', '19:21:11'),
('F1', '2020-03-03', '19:23:38', '19:24:12'),
('F1', '2020-03-03', '19:25:50', '19:26:59'),
('F1', '2020-03-03', '19:29:52', '19:36:21'),
('F1', '2020-03-03', '19:36:35', '19:37:26'),
('F1', '2020-03-03', '19:45:43', '19:46:34'),
('F1', '2020-03-03', '20:04:01', '20:05:50'),
('F1', '2020-03-03', '20:06:11', '20:48:54'),
('F1', '2020-03-03', '20:47:45', '00:00:00'),
('F1', '2020-03-03', '20:49:46', '00:00:00'),
('F1', '2020-03-03', '20:50:20', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `med_ingredients`
--

CREATE TABLE `med_ingredients` (
  `med_id` varchar(10) NOT NULL COMMENT 'The unique identifier for medicines.',
  `main_ingredient` varchar(25) NOT NULL COMMENT 'Main composite ingredient',
  `sub_ingredient` varchar(25) DEFAULT NULL COMMENT 'The sub ingredient of the medicine'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the composition of the medicines available';

-- --------------------------------------------------------

--
-- Table structure for table `nurse_info`
--

CREATE TABLE `nurse_info` (
  `nurse_id` varchar(5) NOT NULL COMMENT 'Unique identifier for nurses. Starts with ''n''.',
  `name` varchar(30) NOT NULL COMMENT 'Name of the nurse.',
  `age` varchar(2) NOT NULL COMMENT 'Age of the nurse.',
  `sex` varchar(8) NOT NULL COMMENT 'Gender of the nurse.',
  `blood_group` varchar(4) NOT NULL COMMENT 'Blood group of the nurse.',
  `working_hours` varchar(2) NOT NULL COMMENT 'The number of hours put in at work everyday.',
  `experience` varchar(2) NOT NULL COMMENT 'Number of years of experience.',
  `insurance_id` varchar(10) NOT NULL COMMENT 'Unique insurance ID of the nurse.',
  `seniority` varchar(1) NOT NULL DEFAULT '0' COMMENT 'A scale of 0-2 which describes the seniority of the nurse.',
  `employed` varchar(2) NOT NULL DEFAULT '1' COMMENT 'Whether the nurse is employed or not'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains basic information about the nurses in the hospital.';

--
-- Dumping data for table `nurse_info`
--

INSERT INTO `nurse_info` (`nurse_id`, `name`, `age`, `sex`, `blood_group`, `working_hours`, `experience`, `insurance_id`, `seniority`, `employed`) VALUES
('N1', 'Navya', '23', 'FEMALE', 'B+', '4`', '3', '1234ADC', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `operation_persons`
--

CREATE TABLE `operation_persons` (
  `appointment_id` varchar(10) NOT NULL COMMENT 'The unique identifier for appointments with operations.',
  `operation_id` varchar(10) NOT NULL COMMENT 'The id of the operation appointment.',
  `nurse_id1` varchar(5) NOT NULL COMMENT 'The nurse helping in the appointment.',
  `nurse_id2` varchar(5) NOT NULL COMMENT 'The nurse helping in the procedure.',
  `nurse_id3` varchar(5) DEFAULT NULL COMMENT 'Optional help in procedure.',
  `doc_id1` varchar(5) NOT NULL COMMENT 'Surgeon performing the procedure.',
  `doc_id2` varchar(5) DEFAULT NULL COMMENT 'Optional surgeon on procedure.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the staff that is performing the procedure.';

-- --------------------------------------------------------

--
-- Table structure for table `operation_theatre`
--

CREATE TABLE `operation_theatre` (
  `op_id` varchar(3) NOT NULL COMMENT 'Unique ID identifying the operation theater.',
  `surgical_lights` tinyint(1) NOT NULL COMMENT 'Whether the operation theater has surgical lights and is working.',
  `operation_table` tinyint(1) NOT NULL COMMENT 'Whether the operation table is ready.',
  `anasthesia_machine` tinyint(1) NOT NULL COMMENT 'Whether the anasthesia machine is ready.',
  `humidity_control` tinyint(1) NOT NULL COMMENT 'Whether the humidity control is working.',
  `air_flow_control` tinyint(1) NOT NULL COMMENT 'Whether the air flow control is working or not.',
  `status` tinyint(1) NOT NULL COMMENT 'Whether the operation theater is ready or not. Based on above boolean values.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains information about operation theater readiness.';

-- --------------------------------------------------------

--
-- Table structure for table `patient_info`
--

CREATE TABLE `patient_info` (
  `p_id` varchar(10) NOT NULL COMMENT 'Unique ID assigned to evry patient to identify them in the system.',
  `name` varchar(30) NOT NULL COMMENT 'Name of the Patient',
  `age` int(2) NOT NULL COMMENT 'Age of the Patient',
  `sex` varchar(8) NOT NULL COMMENT 'Gender of the patient.',
  `weight` int(3) NOT NULL COMMENT 'The weight of the patient in kilograms.',
  `height` int(5) NOT NULL COMMENT 'Height of the Patient in inches',
  `occupation` varchar(30) NOT NULL COMMENT 'Occupation of the patient to recognize lifestyle.',
  `blood_group` varchar(4) NOT NULL COMMENT 'Blood group of the Patient',
  `insurance_id` varchar(10) NOT NULL COMMENT 'The insurance of the patient. Can be ''no'' incase patient has no insurance.',
  `dob` date NOT NULL COMMENT 'The date of birth of the employee.',
  `is_inpatient` tinyint(1) NOT NULL COMMENT 'Whether the patient is resident in the hospital.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the required information about the patient.';

--
-- Dumping data for table `patient_info`
--

INSERT INTO `patient_info` (`p_id`, `name`, `age`, `sex`, `weight`, `height`, `occupation`, `blood_group`, `insurance_id`, `dob`, `is_inpatient`) VALUES
('P1', 'Veena', 45, 'FEMALE', 98, 177, 'Teacher', 'B+', '1q2w3e', '1993-02-08', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy_med_batch`
--

CREATE TABLE `pharmacy_med_batch` (
  `batch_id` varchar(6) NOT NULL COMMENT 'The unique identifier to recognize the batches of medicine.',
  `batch_no` varchar(6) NOT NULL COMMENT 'The batch number to identify seller side sale info..',
  `med_id` varchar(10) NOT NULL COMMENT 'The medicine that is being delivered in batch.',
  `manufacture_date` date NOT NULL COMMENT 'The date of the manufacture of the medicine.',
  `expiry date` date NOT NULL COMMENT 'Date of expiry of the medicine in the batch.',
  `stock_added` int(9) NOT NULL COMMENT 'The amount of medicine given/supplied.',
  `stock_inventory` int(9) NOT NULL COMMENT 'The stock left in inventory.',
  `price` int(9) NOT NULL COMMENT 'The price of the medicine in the specified batch.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the medicine batches information and stock.';

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy_med_info`
--

CREATE TABLE `pharmacy_med_info` (
  `med_id` varchar(10) NOT NULL COMMENT 'Unique identifier for medicines.',
  `med_name` varchar(30) NOT NULL COMMENT 'Name of the medicine identified by med_id.',
  `manufacturer` varchar(30) NOT NULL COMMENT 'Company that manufactures the said medicines.',
  `uses` varchar(200) NOT NULL COMMENT 'The general uses of the medicine.',
  `side_effects` varchar(200) NOT NULL COMMENT 'The possible side effects of the said medicine.',
  `class` varchar(10) NOT NULL COMMENT 'The class of the drug. Determines whether prescriptions re required and other cautionaries.',
  `formulation` varchar(15) NOT NULL COMMENT 'The form factor of the said medicine.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains all the information about the medicines available.';

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy_med_variants`
--

CREATE TABLE `pharmacy_med_variants` (
  `medv_id` varchar(10) NOT NULL COMMENT 'The unique identifier for the medicine variants.',
  `med_id` varchar(10) NOT NULL COMMENT 'The med_id for which the medv_id is the variant/alternative.',
  `formulation` varchar(15) NOT NULL COMMENT 'Form factor of the said medicine.',
  `side_effects` int(11) NOT NULL COMMENT 'possible side effects of the drug. Could be different from med_id side effects.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains all of the variants/alternates of the said med_id.';

-- --------------------------------------------------------

--
-- Table structure for table `prescription_rec`
--

CREATE TABLE `prescription_rec` (
  `p_id` varchar(10) NOT NULL COMMENT 'The unique ID that identifies the patient.',
  `med_id` varchar(10) NOT NULL COMMENT 'The medicine ID that identifies the medicine.',
  `date_of_prescription` date NOT NULL COMMENT 'The date of prescription.',
  `quantity` int(2) NOT NULL COMMENT 'The quantity prescribed.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains all of the prescription information to patient.';

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `id` varchar(6) NOT NULL COMMENT 'The ID that identifies user type.',
  `bachelors_degree` varchar(70) NOT NULL COMMENT 'The bachelors degree of the employee',
  `masters_degree1` varchar(70) DEFAULT NULL COMMENT 'Masters degree of employee',
  `masters_degree2` varchar(20) DEFAULT NULL COMMENT 'Second masters degree.',
  `phd` varchar(100) DEFAULT NULL COMMENT 'Specialization of employee'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the information about qualification of the employee';

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`id`, `bachelors_degree`, `masters_degree1`, `masters_degree2`, `phd`) VALUES
('D1', 'MBd', 'MD', 'NULL', 'Bone Structure'),
('D2', 'MBBS', 'MDD', 'NULL', 'NeoNatal Care'),
('F1', 'BBA', 'null', 'NULL', 'null'),
('N1', 'BBA', 'null', 'NULL', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `room_info`
--

CREATE TABLE `room_info` (
  `room_id` varchar(4) NOT NULL COMMENT 'The room ID identofues the rooms uniquely.',
  `no_of_beds` int(2) NOT NULL COMMENT 'The number of beds available in the room.',
  `type` varchar(15) NOT NULL COMMENT 'The type of sharing the room accomodates.',
  `nurse_id` varchar(4) NOT NULL COMMENT 'The ID of the nurse incharge of this rooms maintenance.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains relevant room information (Basic)';

-- --------------------------------------------------------

--
-- Table structure for table `salary_info`
--

CREATE TABLE `salary_info` (
  `id` varchar(7) NOT NULL COMMENT 'The unique ID of the user (nurses,doctors,front desk).',
  `ctc` varchar(10) NOT NULL COMMENT 'The cost to company of the employee.',
  `pf` varchar(3) NOT NULL COMMENT 'The pf that is being given(in percentage)',
  `gross_salary` varchar(10) NOT NULL COMMENT 'Gross salary of the employee',
  `net_salary` varchar(10) NOT NULL COMMENT 'The net salary after calculating pf',
  `tax_income` varchar(10) NOT NULL COMMENT 'income tax that is supposed to be paid.',
  `pf_amount` varchar(8) NOT NULL COMMENT 'The amount of pf calculated from pf above.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the cost to hospital through employees.';

--
-- Dumping data for table `salary_info`
--

INSERT INTO `salary_info` (`id`, `ctc`, `pf`, `gross_salary`, `net_salary`, `tax_income`, `pf_amount`) VALUES
('D1', '3000000', '2', '2940000', '2040000', '900000', '60000'),
('D2', '1000000', '3', '970000', '820000', '150000', '30000'),
('F1', '200000', '3', '194000', '164000', '30000', '6000');

-- --------------------------------------------------------

--
-- Table structure for table `surgical_batch_info`
--

CREATE TABLE `surgical_batch_info` (
  `batch_id` varchar(9) NOT NULL COMMENT 'Unique identifier that represents the batch ID.',
  `batch_no` varchar(9) NOT NULL COMMENT 'The batch number with respect to the seller.',
  `s_id` varchar(9) NOT NULL COMMENT 'The inventory that is being delivered.',
  `stock_given` int(5) NOT NULL COMMENT 'The amount of stock delivered.',
  `stock_inventory` int(5) NOT NULL COMMENT 'The amount in inventory.',
  `price` int(9) NOT NULL COMMENT 'Price of the batch being delivered.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains information of the delivery of surgical inventory.';

-- --------------------------------------------------------

--
-- Table structure for table `surgical_inventory`
--

CREATE TABLE `surgical_inventory` (
  `s_id` varchar(9) NOT NULL COMMENT 'The unique ID that identifues the surgical inventory.',
  `product_name` varchar(20) NOT NULL COMMENT 'The name of the product identifies by s_id.',
  `material` varchar(20) NOT NULL COMMENT 'The material of the given product(composition).',
  `dimensions` varchar(20) NOT NULL COMMENT 'The dimensions of the product in  string form.',
  `uses` varchar(100) NOT NULL COMMENT 'The uses of the inventory.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains information about the surgical inventory available.';

-- --------------------------------------------------------

--
-- Table structure for table `surg_info`
--

CREATE TABLE `surg_info` (
  `doc_id` varchar(4) NOT NULL COMMENT 'The unique doctor identifier.',
  `no_of_surgeries` int(3) NOT NULL COMMENT 'Number fo surgeries performed.',
  `type` varchar(100) NOT NULL COMMENT 'Brief about the types of operations.',
  `years` int(2) NOT NULL COMMENT 'Years of performing surgery (experience)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains information about the doctors surgical expertise.';

-- --------------------------------------------------------

--
-- Table structure for table `total_bill_records`
--

CREATE TABLE `total_bill_records` (
  `appointment_id` varchar(10) NOT NULL COMMENT 'The appointment ID for which the bill is being generated.',
  `consultation_charges` varchar(8) NOT NULL COMMENT 'The consulation charges of the appointment ID.',
  `total` varchar(10) NOT NULL COMMENT 'The total bill amount.',
  `tax` varchar(10) NOT NULL COMMENT 'tx calculated on the total of the bill.',
  `final_total` varchar(10) NOT NULL COMMENT 'The total bill amount after taxes.',
  `paid` varchar(10) NOT NULL COMMENT 'Either cash or card'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Contains the financial bill information.';

--
-- Dumping data for table `total_bill_records`
--

INSERT INTO `total_bill_records` (`appointment_id`, `consultation_charges`, `total`, `tax`, `final_total`, `paid`) VALUES
('A7', '4', '4870', '584', '5454', 'CARD');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD UNIQUE KEY `diagnosis_id` (`diagnosis_id`);

--
-- Indexes for table `appointment_operation`
--
ALTER TABLE `appointment_operation`
  ADD PRIMARY KEY (`appointment_id`),
  ADD UNIQUE KEY `op_id` (`op_id`),
  ADD UNIQUE KEY `operation_id` (`operation_id`);

--
-- Indexes for table `appointment_room`
--
ALTER TABLE `appointment_room`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `consulting_time`
--
ALTER TABLE `consulting_time`
  ADD PRIMARY KEY (`doc_id`);

--
-- Indexes for table `contact_info`
--
ALTER TABLE `contact_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD PRIMARY KEY (`appointment_id`),
  ADD UNIQUE KEY `diagnosis_id` (`diagnosis_id`);

--
-- Indexes for table `doc_info`
--
ALTER TABLE `doc_info`
  ADD PRIMARY KEY (`doc_id`),
  ADD UNIQUE KEY `lic_no` (`lic_no`),
  ADD UNIQUE KEY `insurance_id` (`insurance_id`);

--
-- Indexes for table `emergency_contact`
--
ALTER TABLE `emergency_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `front_desk_info`
--
ALTER TABLE `front_desk_info`
  ADD PRIMARY KEY (`f_id`),
  ADD UNIQUE KEY `insurance_id` (`insurance_id`);

--
-- Indexes for table `insurance_info`
--
ALTER TABLE `insurance_info`
  ADD PRIMARY KEY (`insurance_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `log_times`
--
ALTER TABLE `log_times`
  ADD PRIMARY KEY (`id`,`date_login`,`login_time`);

--
-- Indexes for table `med_ingredients`
--
ALTER TABLE `med_ingredients`
  ADD PRIMARY KEY (`med_id`);

--
-- Indexes for table `nurse_info`
--
ALTER TABLE `nurse_info`
  ADD PRIMARY KEY (`nurse_id`),
  ADD UNIQUE KEY `insurance_id` (`insurance_id`);

--
-- Indexes for table `operation_persons`
--
ALTER TABLE `operation_persons`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `operation_theatre`
--
ALTER TABLE `operation_theatre`
  ADD PRIMARY KEY (`op_id`);

--
-- Indexes for table `patient_info`
--
ALTER TABLE `patient_info`
  ADD PRIMARY KEY (`p_id`(9)),
  ADD UNIQUE KEY `insurance_id` (`insurance_id`);

--
-- Indexes for table `pharmacy_med_batch`
--
ALTER TABLE `pharmacy_med_batch`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `pharmacy_med_info`
--
ALTER TABLE `pharmacy_med_info`
  ADD PRIMARY KEY (`med_id`);

--
-- Indexes for table `pharmacy_med_variants`
--
ALTER TABLE `pharmacy_med_variants`
  ADD PRIMARY KEY (`medv_id`);

--
-- Indexes for table `prescription_rec`
--
ALTER TABLE `prescription_rec`
  ADD PRIMARY KEY (`p_id`,`med_id`,`date_of_prescription`);

--
-- Indexes for table `qualification`
--
ALTER TABLE `qualification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_info`
--
ALTER TABLE `room_info`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `salary_info`
--
ALTER TABLE `salary_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surgical_batch_info`
--
ALTER TABLE `surgical_batch_info`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `surgical_inventory`
--
ALTER TABLE `surgical_inventory`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `surg_info`
--
ALTER TABLE `surg_info`
  ADD PRIMARY KEY (`doc_id`);

--
-- Indexes for table `total_bill_records`
--
ALTER TABLE `total_bill_records`
  ADD PRIMARY KEY (`appointment_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
